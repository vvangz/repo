export interface ServerSentEvent<T> {
}
