export interface UserRegisterInput {
    readonly phone: string;
    readonly password: string;
}
