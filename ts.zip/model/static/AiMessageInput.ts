import type {MessageType} from '../enums/';
import type {AiMessage_Media} from './';

export interface AiMessageInput {
    readonly type: MessageType;
    readonly textContent: string;
    readonly medias?: ReadonlyArray<AiMessage_Media> | undefined;
    readonly sessionId: string;
}
