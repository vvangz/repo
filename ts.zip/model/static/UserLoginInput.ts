export interface UserLoginInput {
    readonly phone: string;
    readonly password: string;
}
