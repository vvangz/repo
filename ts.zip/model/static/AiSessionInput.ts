export interface AiSessionInput {
    readonly id?: string | undefined;
    readonly name: string;
}
