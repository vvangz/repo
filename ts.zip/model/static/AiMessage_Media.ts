export interface AiMessage_Media {
    readonly type: string;
    readonly data: string;
}
