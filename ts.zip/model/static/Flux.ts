export interface Flux<T> {
    readonly prefetch: number;
}
