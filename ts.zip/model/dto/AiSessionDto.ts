import type {MessageType} from '../enums/';
import type {AiMessage_Media} from '../static/';

export type AiSessionDto = {
    'AiSessionRepository/FETCHER': {
        readonly id: string;
        readonly createdTime: string;
        readonly editedTime: string;
        readonly name: string;
        readonly messages: ReadonlyArray<{
            readonly id: string;
            readonly createdTime: string;
            readonly editedTime: string;
            readonly type: MessageType;
            readonly textContent: string;
            readonly medias?: ReadonlyArray<AiMessage_Media> | undefined;
            readonly sessionId: string;
        }>;
    }
}
