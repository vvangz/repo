export type UserDto = {
    'UserRepository/FETCHER': {
        readonly id: string;
        readonly createdTime: string;
        readonly editedTime: string;
        readonly phone: string;
        readonly password: string;
        readonly avatar?: string | undefined;
        readonly nickname?: string | undefined;
        readonly gender?: string | undefined;
    }
}
