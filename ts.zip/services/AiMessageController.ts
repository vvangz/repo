import type {Executor} from '../';
import type {AiMessageInput, Flux, ServerSentEvent} from '../model/static/';

export class AiMessageController {
    
    constructor(private executor: Executor) {}
    
    readonly chat: (options: AiMessageControllerOptions['chat']) => Promise<
        Flux<ServerSentEvent<string>>
    > = async(options) => {
        let _uri = '/message/chat';
        const _formData = new FormData();
        const _body = options.body;
        _formData.append(
            "input", 
            new Blob(
                [JSON.stringify(_body.input)], 
                {type: "application/json"}
            )
        );
        return (await this.executor({uri: _uri, method: 'POST', body: _formData})) as Promise<Flux<ServerSentEvent<string>>>;
    }
    
    readonly deleteHistory: (options: AiMessageControllerOptions['deleteHistory']) => Promise<
        void
    > = async(options) => {
        let _uri = '/message/history/';
        _uri += encodeURIComponent(options.sessionId);
        return (await this.executor({uri: _uri, method: 'DELETE'})) as Promise<void>;
    }
    
    /**
     * 消息保存
     * 
     * @param input 用户发送的消息/AI回复的消息
     */
    readonly save: (options: AiMessageControllerOptions['save']) => Promise<
        void
    > = async(options) => {
        let _uri = '/message';
        return (await this.executor({uri: _uri, method: 'POST', body: options.body})) as Promise<void>;
    }
}

export type AiMessageControllerOptions = {
    'deleteHistory': {
        readonly sessionId: string
    }, 
    'chat': {
        readonly body: {
            readonly input: string
        }
    }, 
    'save': {
        /**
         * 用户发送的消息/AI回复的消息
         */
        readonly body: AiMessageInput
    }
}
