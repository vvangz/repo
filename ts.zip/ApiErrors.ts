export type AllErrors = {};
export type ApiErrors = {};
