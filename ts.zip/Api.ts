import type {Executor} from './';
import {
    AiMessageController, 
    AiSessionController, 
    DocumentController, 
    UserController
} from './services/';

export class Api {
    
    readonly documentController: DocumentController
    
    readonly aiMessageController: AiMessageController
    
    readonly aiSessionController: AiSessionController
    
    readonly userController: UserController
    
    constructor(executor: Executor) {
        this.documentController = new DocumentController(executor);
        this.aiMessageController = new AiMessageController(executor);
        this.aiSessionController = new AiSessionController(executor);
        this.userController = new UserController(executor);
    }
}